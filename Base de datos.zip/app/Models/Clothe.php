<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Clothe extends Model
{
    use HasFactory;
    
    protected $table = 'clothes';

    protected $primaryKey = 'idClo';

    public $timestamps = false;

    protected $fillable = [
        'gender',
        'type_product',
        'name',
        'photo',
        'color',
        'price',
        'description',
    ];
}
