<?php

namespace Database\Factories;

use App\Models\Clothe;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class ClotheFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'gender' => fake()->randomElement(['H', 'M', 'O']),
            'type_product' => fake()->word(),
            'name' => fake()->word(),
            'photo' => fake()->imageUrl(),
            'color' => ltrim($this->faker->hexcolor, "#"),
            'price' => fake()->numberBetween(0, 127),
            'description' => fake()->paragraph(),
        ];
    }
}
